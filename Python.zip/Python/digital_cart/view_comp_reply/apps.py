from django.apps import AppConfig


class ViewCompReplyConfig(AppConfig):
    name = 'view_comp_reply'
