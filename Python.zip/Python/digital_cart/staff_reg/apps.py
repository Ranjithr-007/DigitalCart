from django.apps import AppConfig


class StaffRegConfig(AppConfig):
    name = 'staff_reg'
