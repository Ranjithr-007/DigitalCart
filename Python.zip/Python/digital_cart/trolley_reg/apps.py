from django.apps import AppConfig


class TrolleyRegConfig(AppConfig):
    name = 'trolley_reg'
