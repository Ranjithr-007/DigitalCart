"""digital_cart URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf.urls import url,include
from django.contrib.staticfiles.urls import staticfiles_urlpatterns

urlpatterns = [
    url('^$', include('login.url_log')),
    url('^staff/', include('staff_reg.url_staff')),
    url('^trolley/', include('trolley_reg.url_trolley')),
    url('^view_com/', include('view_comp_reply.url_view_com_rep')),
    url('^feed/', include('view_feedback.url_feed')),
    url('^view_pro/', include('view_prod.url_view_prod')),


]
urlpatterns+=staticfiles_urlpatterns()