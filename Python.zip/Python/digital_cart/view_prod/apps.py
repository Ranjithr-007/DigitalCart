from django.apps import AppConfig


class ViewProdConfig(AppConfig):
    name = 'view_prod'
