from django.apps import AppConfig


class ViewFeedbackConfig(AppConfig):
    name = 'view_feedback'
